import sys, os
from datetime import datetime
import pandas as pd
def process_data( data ):
  x=[1, 2,3]
  if data:
      print( "Data exists" ); return True
  else: return False
class pipeline:
    def __init__(self): self.data=[]
